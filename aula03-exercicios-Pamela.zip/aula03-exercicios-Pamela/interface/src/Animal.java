interface Animal {
    void comer();
    void dormir();
    void acordar();
}