import java.util.*;
public class Main {
    public static void main(String[] args) {
        Cachorro meuCachorro = new Cachorro();
        meuCachorro.comer();
        meuCachorro.dormir();
        meuCachorro.acordar();
    }
}