public class Cachorro extends Animal {
    String raca;

    void exibirRaca(){
        System.out.println("Raça: " + raca);
    }
}
