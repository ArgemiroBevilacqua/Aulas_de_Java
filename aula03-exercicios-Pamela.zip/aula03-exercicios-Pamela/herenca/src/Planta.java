public class Planta {
    // método
    public void fotossintese() {
        System.out.println("Realizando fotossíntese...");
    }
}
