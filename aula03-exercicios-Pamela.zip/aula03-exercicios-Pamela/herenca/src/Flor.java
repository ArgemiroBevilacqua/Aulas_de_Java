public class Flor extends Planta {
    public void fotossintese() {
        System.out.println("- Flor realizando fotossíntese...");
    }

}
