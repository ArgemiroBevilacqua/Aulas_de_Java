import java.util.*;//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        // Heranças
        Cachorro meuCachorro = new Cachorro();

        meuCachorro.nome = "Rex";
        meuCachorro.idade = 5;
        meuCachorro.raca = "Labrador";

        meuCachorro.exibirDetalhes();
        meuCachorro.exibirRaca();

        // 1)
        System.out.println("\n---- Heranças - Exercicio 1");
        Flor florRosa = new Flor();
        System.out.println("\nEssa flor é uma Rosa Vermelha.");
        florRosa.fotossintese();

        Arvore arvoreManga = new Arvore();
        System.out.println("\nEssa árvore é uma Mangueira.");
        arvoreManga.fotossintese();

    }
}