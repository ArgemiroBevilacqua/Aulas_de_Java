public class Animal {
    String nome;
    int idade;

    // método
    void exibirDetalhes(){
        System.out.println("Nome: " + nome);
        System.out.println("Idade: " + idade);
    }
}
