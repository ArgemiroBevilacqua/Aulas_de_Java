public class Arvore extends Planta{
    public void fotossintese() {
        System.out.println("Árvore realizando fotossíntese...");
    }
}
