import java.util.*;
public class Main {
    public static void main(String[] args) {
        // Exemplo de Listas

        // 1)
        System.out.println("---- Listas - Exercício 1");
        List<Integer> minhaLista = new ArrayList<Integer>();
        minhaLista.add(1);
        minhaLista.add(2);
        minhaLista.add(3);
        minhaLista.add(4);
        minhaLista.add(5);
        System.out.println(minhaLista);
        System.out.println(minhaLista.contains(4));
        System.out.println(minhaLista.size());
        System.out.println(minhaLista.isEmpty());

        minhaLista.clear();
        System.out.println(minhaLista);

        // 2
        System.out.println("\n---- Listas - Exercício 2");
        List<String> listaDeCompras = new ArrayList<>();

        listaDeCompras.add("Maçã");
        listaDeCompras.add("Banana");
        listaDeCompras.add("Leite");
        listaDeCompras.add("Pão");

        System.out.println("Itens na lista de compras:");
        for (String item : listaDeCompras) {
            System.out.println(item);
        }

        listaDeCompras.remove("Pão");

        System.out.println("\n'Pão' foi removido da sua lista!");
        for (String item : listaDeCompras) {
            System.out.println(item);
        }
    }
}