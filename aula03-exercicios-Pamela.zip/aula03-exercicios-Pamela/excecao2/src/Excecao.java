public class Excecao extends Exception {
    public Excecao(String mensagem){
        super(mensagem);
    }
}
