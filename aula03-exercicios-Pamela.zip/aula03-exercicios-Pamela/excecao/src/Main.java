public class Main {
    public static void main(String[] args){
        try {
            int[] numeros = {1, 2, 3};
            System.out.println(numeros[10]); // esse trecho lançará uma exceção pq esse índice não existe
        } catch (ArrayIndexOutOfBoundsException e){
            System.out.println("Índice do array fora dos limites!");
        } finally {
            System.out.println("Este bloco 'finally' sempre será executado."); //  o finally se executa com ou sem exceção lançada
        }
    }
}